# To create db in Heroku
from app import app, db
db.create_all()