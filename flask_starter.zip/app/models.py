from app import db

class Blockchain(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(64), index=True, unique=True)
    hash = db.Column(db.String(64))
    previous = db.Column(db.String(64))
    data = db.Column(db.String(128))
    nonce = db.Column(db.String(64))

    def __repr__(self):
        return '<Blockchain {}>'.format(self.number)  