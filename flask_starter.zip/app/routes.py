# routes.py returns the complete HTML pages from view function
# Import libraries
import os
from app import app
from app import db
from app.models import Blockchain
from flask import render_template, redirect, request, url_for, flash, session
from werkzeug.urls import url_parse
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_login import current_user, login_user, logout_user, login_required



# Route for home page and Chatbot
@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')